(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const header = $('#header');
  const navLinks = $('#navLinks');
  const hamburger = $('#hamburger');

  const btnTopo = $('#btnTopo');
  const anoAtual = $('#anoAtual');

  const form = $('#formAgendamento');
  const confirmacao = $('#confirmacao');
  const confirmacaoTexto = $('#confirmacaoTexto');
  const btnNovo = $('#btnNovo');

  const galeriaGrid = $('.galeria-grid');
  const filtroBtns = $$('.filtro-btn');

  const lightbox = $('#lightbox');
  const lbBackdrop = $('#lbBackdrop');
  const lbImg = $('#lbImg');
  const lbFechar = $('#lbFechar');
  const lbPrev = $('#lbPrev');
  const lbNext = $('#lbNext');

  const inputNome = $('#nome');
  const inputTel = $('#tel');
  const selectServico = $('#servico');
  const inputData = $('#data');
  const selectHorario = $('#horario');

  const erroNome = $('#erroNome');
  const erroTel = $('#erroTel');
  const erroServico = $('#erroServico');
  const erroData = $('#erroData');
  const erroHorario = $('#erroHorario');

  const sections = $$('main section, section[id]');
  const navAnchors = $$('.nav-link');

  let lbIndex = -1;
  let lbItems = [];

  function setScrolledHeader() {
    if (!header) return;
    header.classList.toggle('scrolled', window.scrollY > 10);
  }

  function toggleMenu(forceOpen) {
    if (!navLinks || !hamburger) return;
    const isOpen = typeof forceOpen === 'boolean' ? forceOpen : !navLinks.classList.contains('aberto');
    navLinks.classList.toggle('aberto', isOpen);
    hamburger.classList.toggle('aberto', isOpen);
    hamburger.setAttribute('aria-expanded', String(isOpen));
    document.body.classList.toggle('no-scroll', isOpen);
  }

  function closeMenu() {
    toggleMenu(false);
  }

  function setActiveNavLinkByScroll() {
    if (!navAnchors.length) return;
    const offset = 110;
    const y = window.scrollY + offset;

    let currentId = '';
    for (const sec of sections) {
      const id = sec.getAttribute('id');
      if (!id) continue;
      const top = sec.offsetTop;
      const bottom = top + sec.offsetHeight;
      if (y >= top && y < bottom) {
        currentId = id;
        break;
      }
    }

    for (const a of navAnchors) {
      const href = a.getAttribute('href') || '';
      const id = href.startsWith('#') ? href.slice(1) : '';
      a.classList.toggle('ativo', Boolean(currentId && id === currentId));
    }
  }

  function setBtnTopoVisibility() {
    if (!btnTopo) return;
    btnTopo.classList.toggle('visivel', window.scrollY > 400);
  }

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function observeFadeIn() {
    const els = $$('.fade-in');
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add('visivel');
            io.unobserve(e.target);
          }
        }
      },
      { threshold: 0.12 }
    );
    for (const el of els) io.observe(el);
  }

  function applyPhoneMask(value) {
    const digits = (value || '').replace(/\D+/g, '').slice(0, 11);
    const ddd = digits.slice(0, 2);
    const part1 = digits.slice(2, 7);
    const part2 = digits.slice(7, 11);

    if (digits.length <= 2) return ddd ? `(${ddd}` : '';
    if (digits.length <= 7) return `(${ddd}) ${digits.slice(2)}`;
    if (digits.length <= 10) return `(${ddd}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
    return `(${ddd}) ${part1}-${part2}`;
  }

  function setFieldError(field, errorEl, message) {
    if (field) field.classList.toggle('invalido', Boolean(message));
    if (errorEl) errorEl.textContent = message || '';
  }

  function validateForm() {
    let ok = true;

    const nome = (inputNome?.value || '').trim();
    if (nome.length < 3) {
      ok = false;
      setFieldError(inputNome, erroNome, 'Informe seu nome completo.');
    } else {
      setFieldError(inputNome, erroNome, '');
    }

    const telDigits = (inputTel?.value || '').replace(/\D+/g, '');
    if (telDigits.length < 10) {
      ok = false;
      setFieldError(inputTel, erroTel, 'Informe um telefone válido com DDD.');
    } else {
      setFieldError(inputTel, erroTel, '');
    }

    const servico = (selectServico?.value || '').trim();
    if (!servico) {
      ok = false;
      setFieldError(selectServico, erroServico, 'Selecione um serviço.');
    } else {
      setFieldError(selectServico, erroServico, '');
    }

    const data = inputData?.value || '';
    if (!data) {
      ok = false;
      setFieldError(inputData, erroData, 'Selecione uma data.');
    } else {
      setFieldError(inputData, erroData, '');
    }

    const horario = (selectHorario?.value || '').trim();
    if (!horario) {
      ok = false;
      setFieldError(selectHorario, erroHorario, 'Selecione um horário.');
    } else {
      setFieldError(selectHorario, erroHorario, '');
    }

    return ok;
  }

  function showConfirmation() {
    if (!form || !confirmacao || !confirmacaoTexto) return;
    const nome = (inputNome?.value || '').trim();
    const tel = (inputTel?.value || '').trim();
    const servico = (selectServico?.value || '').trim();
    const data = inputData?.value || '';
    const horario = (selectHorario?.value || '').trim();

    const dataFmt = (() => {
      if (!data) return '';
      const [yyyy, mm, dd] = data.split('-');
      if (!yyyy || !mm || !dd) return data;
      return `${dd}/${mm}/${yyyy}`;
    })();

    confirmacaoTexto.textContent =
      `${nome}, seu horário para "${servico}" foi reservado para ${dataFmt} às ${horario}. ` +
      `Entraremos em contato no ${tel} para confirmar.`;

    form.style.display = 'none';
    confirmacao.classList.add('visivel');
  }

  function resetForm() {
    if (!form || !confirmacao) return;
    form.reset();
    form.style.display = '';
    confirmacao.classList.remove('visivel');

    setFieldError(inputNome, erroNome, '');
    setFieldError(inputTel, erroTel, '');
    setFieldError(selectServico, erroServico, '');
    setFieldError(inputData, erroData, '');
    setFieldError(selectHorario, erroHorario, '');
  }

  function setupGalleryFilter() {
    if (!galeriaGrid || !filtroBtns.length) return;
    const items = $$('.g-item', galeriaGrid);

    const apply = (filtro) => {
      for (const b of filtroBtns) b.classList.toggle('ativo', b.dataset.filtro === filtro);
      for (const it of items) {
        const cat = it.getAttribute('data-cat') || '';
        const show = filtro === 'todos' ? true : cat === filtro;
        it.classList.toggle('oculto', !show);
      }
    };

    for (const b of filtroBtns) {
      b.addEventListener('click', () => apply(b.dataset.filtro || 'todos'));
    }
  }

  function collectLightboxItems() {
    if (!galeriaGrid) return [];
    const visible = $$('.g-item', galeriaGrid).filter((it) => !it.classList.contains('oculto'));
    return visible.map((it) => {
      const img = $('img', it);
      const title = $('.g-overlay span', it)?.textContent?.trim() || img?.alt || 'Foto';
      return {
        src: img?.getAttribute('src') || '',
        alt: img?.getAttribute('alt') || title,
        title,
      };
    }).filter((x) => x.src);
  }

  function openLightbox(index) {
    if (!lightbox || !lbBackdrop || !lbImg) return;
    lbItems = collectLightboxItems();
    if (!lbItems.length) return;
    lbIndex = Math.max(0, Math.min(index, lbItems.length - 1));

    const item = lbItems[lbIndex];
    lbImg.src = item.src;
    lbImg.alt = item.alt;

    lbBackdrop.classList.add('ativo');
    lightbox.classList.add('ativo');
    document.body.classList.add('no-scroll');
  }

  function closeLightbox() {
    if (!lightbox || !lbBackdrop || !lbImg) return;
    lightbox.classList.remove('ativo');
    lbBackdrop.classList.remove('ativo');
    lbImg.src = '';
    lbIndex = -1;
    document.body.classList.remove('no-scroll');
  }

  function moveLightbox(delta) {
    if (lbIndex < 0) return;
    if (!lbItems.length) lbItems = collectLightboxItems();
    if (!lbItems.length) return;
    lbIndex = (lbIndex + delta + lbItems.length) % lbItems.length;
    const item = lbItems[lbIndex];
    lbImg.src = item.src;
    lbImg.alt = item.alt;
  }

  function setupLightbox() {
    if (!galeriaGrid || !lightbox || !lbBackdrop) return;

    galeriaGrid.addEventListener('click', (e) => {
      const item = e.target instanceof Element ? e.target.closest('.g-item') : null;
      if (!item || item.classList.contains('oculto')) return;
      const visible = $$('.g-item', galeriaGrid).filter((it) => !it.classList.contains('oculto'));
      const index = visible.indexOf(item);
      openLightbox(index >= 0 ? index : 0);
    });

    lbBackdrop.addEventListener('click', closeLightbox);
    lbFechar?.addEventListener('click', closeLightbox);
    lbPrev?.addEventListener('click', () => moveLightbox(-1));
    lbNext?.addEventListener('click', () => moveLightbox(1));

    window.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('ativo')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') moveLightbox(-1);
      if (e.key === 'ArrowRight') moveLightbox(1);
    });
  }

  function setupForm() {
    if (!form) return;

    // Data mínima: hoje
    if (inputData) {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');
      inputData.min = `${yyyy}-${mm}-${dd}`;
    }

    inputTel?.addEventListener('input', () => {
      const masked = applyPhoneMask(inputTel.value);
      inputTel.value = masked;
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!validateForm()) return;
      showConfirmation();
    });

    btnNovo?.addEventListener('click', () => {
      resetForm();
      $('#agendamento')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  function setupNav() {
    hamburger?.addEventListener('click', () => toggleMenu());
    for (const a of navAnchors) {
      a.addEventListener('click', () => closeMenu());
    }

    window.addEventListener('scroll', () => {
      setScrolledHeader();
      setBtnTopoVisibility();
      setActiveNavLinkByScroll();
    }, { passive: true });

    setScrolledHeader();
    setBtnTopoVisibility();
    setActiveNavLinkByScroll();
  }

  function setupFooterYear() {
    if (anoAtual) anoAtual.textContent = String(new Date().getFullYear());
  }

  function setupTopButton() {
    btnTopo?.addEventListener('click', scrollToTop);
  }

  function init() {
    setupFooterYear();
    setupNav();
    setupTopButton();
    observeFadeIn();
    setupGalleryFilter();
    setupLightbox();
    setupForm();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
