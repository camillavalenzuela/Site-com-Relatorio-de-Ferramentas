
  # Barbershop Website

  This is a code bundle for Barbershop Website. The original project is available at https://www.figma.com/design/WxXnAk6IhQnly06uywvE3f/Barbershop-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  